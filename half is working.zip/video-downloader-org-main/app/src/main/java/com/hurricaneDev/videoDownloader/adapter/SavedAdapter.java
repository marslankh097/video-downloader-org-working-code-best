package com.hurricaneDev.videoDownloader.adapter;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import com.hurricaneDev.videoDownloader.R;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class SavedAdapter extends RecyclerView.Adapter<SavedAdapter.SavedHolder> {

    private List<File> list;
    private Context context;

    public SavedAdapter(List<File> nonExistentFiles, Context context) {
        this.context = context;
        this.list = loadFiles();
    }

    // Load files from app's own folder Android/data/com.app/files
    private List<File> loadFiles() {
        File folder = context.getExternalFilesDir(null); // your app folder
        List<File> files = new ArrayList<>();

        if (folder != null && folder.exists()) {

            // LOG FOLDER PATH
            System.out.println("📁 Folder Path: " + folder.getAbsolutePath());

            File[] all = folder.listFiles();

            if (all == null) {
                System.out.println("⚠ listFiles() returned NULL");
                return files;
            }

            // LOG NUMBER OF FILES
            System.out.println("📄 Total files found: " + all.length);

            for (File f : all) {

                // LOG EACH FILE NAME
                System.out.println("👉 File: " + f.getName() + " | size=" + f.length());

                if (f.isFile()) files.add(f);
            }
        } else {
            System.out.println("❌ Folder does NOT exist or is NULL");
        }

        return files;
    }

    @NonNull
    @Override
    public SavedHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context)
                .inflate(R.layout.downloads_completed_item, parent, false);
        return new SavedHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SavedHolder holder, @SuppressLint("RecyclerView") int position) {
        File file = list.get(position);

        holder.name.setText(file.getName());
        holder.size.setText("Size " + getFileSizeWithUnit(file));

        // Load thumbnail
        Glide.with(context)
                .load(file)
                .into(holder.thumbnail);

    //    holder.menu.setOnClickListener(v -> popUp(v, file));
        holder.thumbnail.setOnClickListener(v -> openVideo(file));

    }

    private void openVideo(File f) {
        Uri uri = FileProvider.getUriForFile(
                context,
                context.getPackageName() + ".file.provider",
                f
        );

        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(uri, "video/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        try {
            context.startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(context, "No video player found", Toast.LENGTH_SHORT).show();
        }
    }

    // Popup menu: delete/share
    private void popUp(View view, File f) {
        PopupMenu popup = new PopupMenu(context, view);
        popup.getMenuInflater().inflate(R.menu.download_menu, popup.getMenu());

        popup.setOnMenuItemClickListener(item -> {
            int id = item.getItemId();

            // Delete
            if (id == R.id.download_delete) {
                new AlertDialog.Builder(context)
                        .setMessage("Delete this file?")
                        .setPositiveButton("Yes", (d, w) -> {
                            if (f.delete()) {
                                list.remove(f);
                                notifyDataSetChanged();
                            }
                        })
                        .setNegativeButton("No", null)
                        .show();
                return true;
            }

            // Share
            if (id == R.id.download_share) {

                Uri uri = FileProvider.getUriForFile(
                        context,
                        context.getPackageName() + ".file.provider",
                        f
                );

                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("*/*");
                share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                share.putExtra(Intent.EXTRA_STREAM, uri);

                try {
                    context.startActivity(Intent.createChooser(share, "Share via"));
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(context, "No sharing app found", Toast.LENGTH_SHORT).show();
                }

                return true;
            }

            return false;
        });

        popup.show();
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    // ViewHolder
    public static class SavedHolder extends RecyclerView.ViewHolder {
        TextView name, size;
        ImageView thumbnail;
     //   CardView menu;

        public SavedHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.downloadVideoName);
            size = itemView.findViewById(R.id.downloadProgressText);
            thumbnail = itemView.findViewById(R.id.videoThumbnail);
        //    menu = itemView.findViewById(R.id.optionLayout);
        }
    }

    // Get file size
    public static String getFileSizeWithUnit(File file) {
        long s = file.length();
        if (s < 1024) return s + " B";
        else if (s < 1048576) return String.format("%.2f KB", s / 1024.0);
        else if (s < 1073741824) return String.format("%.2f MB", s / 1048576.0);
        else return String.format("%.2f GB", s / 1073741824.0);
    }
}
