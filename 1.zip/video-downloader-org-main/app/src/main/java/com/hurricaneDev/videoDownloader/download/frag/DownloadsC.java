package com.hurricaneDev.videoDownloader.download.frag;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.hurricaneDev.videoDownloader.activity.MainActivity;
import com.hurricaneDev.videoDownloader.R;
import com.hurricaneDev.videoDownloader.model.VDFragment;

import java.io.File;

public class DownloadsC extends VDFragment implements MainActivity.OnBackPressedListener,
        DownloadsInProgress.OnNumDownloadsInProgressChangeListener,
        DownloadsCompleted.OnNumDownloadsCompletedChangeListener,
        DownloadsInProgress.OnAddDownloadedVideoToCompletedListener {

    private static final String COMPLETE = "downloadsCompleted";
    private View view;
    private ViewPager pager;
    private DownloadsCompleted downloadsComplete;

    @Override
    public void onDestroy() {
        Fragment fragment;
        if ((fragment = getFragmentManager().findFragmentByTag(COMPLETE)) != null) {
            getFragmentManager().beginTransaction().remove(fragment).commit();
        }
        super.onDestroy();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        setRetainInstance(true);

        if (view == null) {
            view = inflater.inflate(R.layout.downloads_c, container, false);

            AdView mAdView = view.findViewById(R.id.adView);
            AdRequest adRequest = new AdRequest.Builder().build();
            mAdView.loadAd(adRequest);

            getVDActivity().setOnBackPressedListener(this);

            pager = view.findViewById(R.id.progress_pager);
            pager.setAdapter(new PagerAdapter());

            Toolbar toolbar = view.findViewById(R.id.download_toolbar);
            toolbar.setOnMenuItemClickListener(item -> {
                if (item.getItemId() == R.id.delete_all_action) {
                    new AlertDialog.Builder(getContext())
                            .setMessage(getResources().getString(R.string.empty_download_list))
                            .setNegativeButton("Ok", (dialog, which) -> deleteAll())
                            .show();
                }
                return true;
            });

            downloadsComplete = new DownloadsCompleted();
            downloadsComplete.setOnNumDownloadsCompletedChangeListener(this);

            getFragmentManager().beginTransaction()
                    .add(pager.getId(), downloadsComplete, COMPLETE)
                    .commit();
        }

        return view;
    }

    private void deleteAll() {
        File dir = getContext().getExternalFilesDir(null);
        if (dir != null && dir.isDirectory()) {
            File[] files = dir.listFiles();
            if (files != null) {
                for (File f : files) {
                    f.delete();
                }
            }
        }
     //   downloadsComplete.refreshList();
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        pager.setCurrentItem(0);
    }

    @Override
    public void onBackpressed() {
        getVDActivity().getBrowserManager().unhideCurrentWindow();
        getFragmentManager().beginTransaction().remove(this).commit();
    }

    @Override
    public void onNumDownloadsInProgressChange() {}

    @Override
    public void onNumDownloadsCompletedChange() {}

    @Override
    public void onAddDownloadedVideoToCompleted(String name, String type) {
        Toast.makeText(getContext(), name, Toast.LENGTH_SHORT).show();
    }

    class PagerAdapter extends androidx.viewpager.widget.PagerAdapter {
        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            return downloadsComplete;
        }

        @Override
        public int getCount() { return 1; }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {}

        @Override
        public boolean isViewFromObject(View view, Object object) {
            return ((Fragment) object).getView() == view;
        }
    }
}
