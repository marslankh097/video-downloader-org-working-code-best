package com.hurricaneDev.videoDownloader.download.frag;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;
import com.hurricaneDev.videoDownloader.R;
import com.hurricaneDev.videoDownloader.VDApp;
import com.hurricaneDev.videoDownloader.adapter.SavedAdapter;
import com.hurricaneDev.videoDownloader.download.list.CompletedVideos;
import com.hurricaneDev.videoDownloader.model.VDFragment;

import java.io.File;
import java.util.List;

public class DownloadsCompleted extends VDFragment implements DownloadsInProgress.OnAddDownloadedVideoToCompletedListener {

    private View view;
    private RecyclerView downloadsList;
    private LinearLayout empty;
    private SavedAdapter adapter;
    private CompletedVideos completedVideos;
    private OnNumDownloadsCompletedChangeListener listener;

    public interface OnNumDownloadsCompletedChangeListener {
        void onNumDownloadsCompletedChange();
    }

    public void setOnNumDownloadsCompletedChangeListener(OnNumDownloadsCompletedChangeListener listener) {
        this.listener = listener;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        setRetainInstance(true);

        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());

        if (view == null) {
            view = inflater.inflate(R.layout.downloads_completed, container, false);

            downloadsList = view.findViewById(R.id.downloadsCompletedList);
            empty = view.findViewById(R.id.empty_download);

            Button clearAll = view.findViewById(R.id.clearAllFinishedButton);
            Button goToFolder = view.findViewById(R.id.goToFolder);

            Dexter.withContext(getContext())
                    .withPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                    .withListener(new PermissionListener() {
                        @Override
                        public void onPermissionGranted(PermissionGrantedResponse response) {

                            File folder = getContext().getExternalFilesDir(null);

                            if (folder != null && folder.exists()) {
                                File[] files = folder.listFiles();

                                if (files != null && files.length > 0) {

                                    empty.setVisibility(View.GONE);
                                    downloadsList.setVisibility(View.VISIBLE);

                                    adapter = new SavedAdapter(null, getContext());
                                    downloadsList.setLayoutManager(new GridLayoutManager(getActivity(), 2));
                                    downloadsList.setAdapter(adapter);
                                    downloadsList.setHasFixedSize(true);

                                } else {
                                    empty.setVisibility(View.VISIBLE);
                                }
                            }
                        }

                        @Override
                        public void onPermissionDenied(PermissionDeniedResponse response) {}

                        @Override
                        public void onPermissionRationaleShouldBeShown(PermissionRequest permission, PermissionToken token) {
                            token.continuePermissionRequest();
                        }
                    }).check();

            clearAll.setOnClickListener(v ->
                    new AlertDialog.Builder(getActivity())
                            .setMessage(getResources().getString(R.string.empty_download_list))
                            .setPositiveButton("Yes", (dialog, which) -> {
                                File folder = getContext().getExternalFilesDir(null);
                                if (folder != null) {
                                    File[] files = folder.listFiles();
                                    if (files != null) {
                                        for (File f : files) f.delete();
                                    }
                                }
                                if (adapter != null) adapter.notifyDataSetChanged();
                                empty.setVisibility(View.VISIBLE);
                                downloadsList.setVisibility(View.GONE);
                                if (listener != null) listener.onNumDownloadsCompletedChange();
                            })
                            .setNegativeButton("No", null)
                            .show()
            );

            goToFolder.setOnClickListener(v -> {
                File folder = getContext().getExternalFilesDir(null);
                if (folder != null) {
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setDataAndType(Uri.fromFile(folder), "video/*");
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                }
            });
        }

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        if (listener != null) listener.onNumDownloadsCompletedChange();
    }

    @Override
    public void onAddDownloadedVideoToCompleted(String name, String type) {
        if (adapter != null) {
            adapter = new SavedAdapter(null, getContext());
            downloadsList.setAdapter(adapter);
        }
        if (listener != null) listener.onNumDownloadsCompletedChange();
    }
}
